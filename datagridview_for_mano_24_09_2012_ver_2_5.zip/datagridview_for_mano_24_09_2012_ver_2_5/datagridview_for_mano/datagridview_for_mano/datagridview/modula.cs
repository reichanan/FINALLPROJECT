﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;

using olemission;


namespace datagridview
{
    public sealed class Modula
    {
        private static volatile Modula instance;
        private static object syncRoot = new Object();
        private static clsmissionClass mission ;
        private int m_timeout;
            

        private Modula() 
        { 
            mission = new clsmissionClass();
            mission.initialize("c:\\win_ese5\\initolemission.ini");
        
        }

        public static Modula Instance()
        {

                if (instance == null)
                {
                    lock (syncRoot)
                    {
                        if (instance == null)
                            instance = new Modula();
                    }
                }

                return instance;

        }


        public object LUCall(int LU, int machine, int exitcode)
        {
	        object v1 = LU;
            object v2 = "C";
            object v3 = machine;
            object v4 = "B";
            object v5 = exitcode;
            Thread.Sleep(m_timeout);
            object ret2 = mission.create(v1, v2, v3, v4, v5);
	        return ret2;

        }



    public object RemotePickingEnd(int LU, int machine, int exitcode)
    {
	    object v1 = LU;  
	    object v2 = "B";  
	    object v3 = machine;  
	    object v4 = "C";  
	    object v5 = exitcode;  
	    object ret2 = mission.create(v1, v2, v3, v4, v5);
	    Thread.Sleep(m_timeout);
	    return ret2;

    }




    public void Release()
    {
           while (Marshal.ReleaseComObject(mission) > 0) { }
           Marshal.FinalReleaseComObject(mission);
           mission = null;
    }


    public object Delall(int machine)
    {

	    object v1 = machine;
	    object ret1 = mission.delall(v1);
	    Thread.Sleep(m_timeout);
	    return ret1;


    }



    public object Del(int LU)
    {
	    object v1 = LU;
	    object ret1 =mission.del(v1);
	    Thread.Sleep(m_timeout);
	    return ret1;

    }


    public object Read(int LU)
    {
	    object v1 = LU;
	    object ret1 = mission.read(v1);
        Thread.Sleep(m_timeout);
	    return ret1;

    }



    public object ClearTable()
    {
	    object ret1 = mission.zaptab();
	    Thread.Sleep(m_timeout);
	    return ret1;
	

    }




    public object DBMaint()
    {
	    object ret1 = mission.manuttab();
        Thread.Sleep(m_timeout);
	    return ret1;

    }


    public void SetTimeOut(int machine)
    {

	    m_timeout = machine;
    }


    public object zaptab()
    {
	    object ret1 = mission.zaptab();
        Thread.Sleep(m_timeout);
	    return ret1;

    }


    public object checkconn()
    {
	    object ret1 = mission.checkconn();
        Thread.Sleep(m_timeout);
        return ret1;
    }

   }
    
    

}
