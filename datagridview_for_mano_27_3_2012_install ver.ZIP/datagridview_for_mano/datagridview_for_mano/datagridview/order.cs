﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace datagridview
{
    public class order
    {
        
       
        
        private string AEDAT = string.Empty;
        private string AXISX = string.Empty;
        private string AXISY = string.Empty;
        private string BSART = string.Empty;
        private string EBELN = string.Empty;
        private string EBELP = string.Empty;
        private string ERNAM = string.Empty;
        private string LGOBE = string.Empty;
        private string LGORT = string.Empty;
        private string MAKTX = string.Empty;
        private string MATNR = string.Empty;
        private string MEINS = string.Empty;
        private string MENGE = string.Empty;
        private string MENGE2 =string.Empty;
        private string TOWER = string.Empty;
        private string TRAY =  string.Empty;
        private string DONE = string.Empty;
        private string INBOX = string.Empty;


        public string _AEDAT
        {
            get
            {
                return AEDAT;
            }
            set
            {
                AEDAT = value;
            }
        }
        public string _AXISX
        {
            get
            {
                return AXISX;
            }
            set
            {
                AXISX = value;
            }
        }
        public string _AXISY
        {
            get
            {
                return AXISY;
            }
            set
            {
                AXISY = value;
            }
        }
        public string _BSART
        {
            get
            {
                return BSART;
            }
            set
            {
                BSART = value;
            }
        }
        public string _EBELN
        {
            get
            {
                return EBELN;
            }
            set
            {
                EBELN = value;
            }
        }
        public string _EBELP
        {
            get
            {
                return EBELP;
            }
            set
            {
                EBELP = value;
            }
        }
        public string _ERNAM
        {
            get
            {
                return ERNAM;
            }
            set
            {
                ERNAM = value;
            }
        }
        public string _LGOBE
        {
            get
            {
                return LGOBE;
            }
            set
            {
                LGOBE = value;
            }
        }
        public string _LGORT
        {
            get
            {
                return LGORT;
            }
            set
            {
                LGORT = value;
            }
        }
        public string _MAKTX
        {
            get
            {
                return MAKTX;
            }
            set
            {
                MAKTX = value;
            }
        }
        public string _MATNR
        {
            get
            {
                return MATNR;
            }
            set
            {
               MATNR = value;
            }
        }
        public string _MEINS
        {
            get
            {
                return MEINS;
            }
            set
            {
                MEINS = value;
            }
        }
        public string _MENGE
        {
            get
            {
                return MENGE;
            }
            set
            {
                MENGE = value;
            }
        }
        public string _MENGE2
        {
            get
            {
                return MENGE2;
            }
            set
            {
                MENGE2 = value;
            }
        }
        public string _TOWER
        {
            get
            {
                return TOWER;
            }
            set
            {
                TOWER = value;
            }
        }
        public string _TRAY
        {
            get
            {
                return TRAY;
            }
            set
            {
                TRAY = value;
            }
        }

        public string _DONE
        {
            get
            {
                return DONE;
            }
            set
            {
                DONE = value;
            }
        }


        public string _INBOX
        {
            get
            {
                return INBOX;
            }
            set
            {
                INBOX = value;
            }
        }



    }
}
