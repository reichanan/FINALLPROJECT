﻿namespace datagridview
{
    partial class proceedOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.callMigdal = new System.Windows.Forms.Button();
            this.save = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.EBELN = new System.Windows.Forms.Label();
            this.EBELP = new System.Windows.Forms.Label();
            this.MATNR = new System.Windows.Forms.Label();
            this.MEINS = new System.Windows.Forms.Label();
            this.MAKTX = new System.Windows.Forms.Label();
            this.LGORT = new System.Windows.Forms.Label();
            this.MENGE = new System.Windows.Forms.Label();
            this.exit = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.AXISX = new System.Windows.Forms.Label();
            this.AXISY = new System.Windows.Forms.Label();
            this.LGOBE = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.TRAY = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.inbox = new System.Windows.Forms.Label();
            this.TOWER = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // callMigdal
            // 
            this.callMigdal.BackColor = System.Drawing.Color.Gray;
            this.callMigdal.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.callMigdal.Location = new System.Drawing.Point(51, 230);
            this.callMigdal.Name = "callMigdal";
            this.callMigdal.Size = new System.Drawing.Size(87, 23);
            this.callMigdal.TabIndex = 0;
            this.callMigdal.Text = "התחל הזמנה";
            this.callMigdal.UseVisualStyleBackColor = false;
            this.callMigdal.Visible = false;
            this.callMigdal.Click += new System.EventHandler(this.callMigdal_Click);
            // 
            // save
            // 
            this.save.BackColor = System.Drawing.Color.Gray;
            this.save.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.save.Location = new System.Drawing.Point(163, 230);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(111, 23);
            this.save.TabIndex = 1;
            this.save.Text = "בצע";
            this.save.UseVisualStyleBackColor = false;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "מספר הזמנה";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(301, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "שורה";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(55, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "מק\'ט";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(52, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "יחידת מידה";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(55, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "תאור פריט";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(299, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "אתר";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(55, 204);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "כמות לניפוק";
            // 
            // EBELN
            // 
            this.EBELN.AutoSize = true;
            this.EBELN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.EBELN.Location = new System.Drawing.Point(172, 27);
            this.EBELN.Name = "EBELN";
            this.EBELN.Size = new System.Drawing.Size(57, 15);
            this.EBELN.TabIndex = 11;
            this.EBELN.Text = "EBELN  ";
            // 
            // EBELP
            // 
            this.EBELP.AutoSize = true;
            this.EBELP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.EBELP.Location = new System.Drawing.Point(375, 27);
            this.EBELP.Name = "EBELP";
            this.EBELP.Size = new System.Drawing.Size(48, 15);
            this.EBELP.TabIndex = 12;
            this.EBELP.Text = "EBELP";
            // 
            // MATNR
            // 
            this.MATNR.AutoSize = true;
            this.MATNR.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MATNR.Location = new System.Drawing.Point(172, 75);
            this.MATNR.Name = "MATNR";
            this.MATNR.Size = new System.Drawing.Size(53, 15);
            this.MATNR.TabIndex = 14;
            this.MATNR.Text = "MATNR";
            // 
            // MEINS
            // 
            this.MEINS.AutoSize = true;
            this.MEINS.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MEINS.Location = new System.Drawing.Point(174, 131);
            this.MEINS.Name = "MEINS";
            this.MEINS.Size = new System.Drawing.Size(48, 15);
            this.MEINS.TabIndex = 15;
            this.MEINS.Text = "MEINS";
            // 
            // MAKTX
            // 
            this.MAKTX.AutoSize = true;
            this.MAKTX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MAKTX.Location = new System.Drawing.Point(172, 100);
            this.MAKTX.Name = "MAKTX";
            this.MAKTX.Size = new System.Drawing.Size(261, 15);
            this.MAKTX.TabIndex = 16;
            this.MAKTX.Tag = "    ";
            this.MAKTX.Text = "123456789012345678123456789012345678";
            // 
            // LGORT
            // 
            this.LGORT.AutoSize = true;
            this.LGORT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LGORT.Location = new System.Drawing.Point(372, 52);
            this.LGORT.Name = "LGORT";
            this.LGORT.Size = new System.Drawing.Size(51, 15);
            this.LGORT.TabIndex = 18;
            this.LGORT.Text = "LGORT";
            // 
            // MENGE
            // 
            this.MENGE.AutoSize = true;
            this.MENGE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.MENGE.Location = new System.Drawing.Point(172, 204);
            this.MENGE.Name = "MENGE";
            this.MENGE.Size = new System.Drawing.Size(53, 15);
            this.MENGE.TabIndex = 19;
            this.MENGE.Text = "MENGE";
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Gray;
            this.exit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.exit.Location = new System.Drawing.Point(297, 230);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(87, 23);
            this.exit.TabIndex = 20;
            this.exit.Text = "סיום איסוף";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(245, 204);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "כמות בפועל";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(256, 169);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(11, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "-";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(321, 169);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(11, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "-";
            // 
            // AXISX
            // 
            this.AXISX.AutoSize = true;
            this.AXISX.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.AXISX.Location = new System.Drawing.Point(225, 167);
            this.AXISX.Name = "AXISX";
            this.AXISX.Size = new System.Drawing.Size(25, 15);
            this.AXISX.TabIndex = 27;
            this.AXISX.Text = "XX";
            // 
            // AXISY
            // 
            this.AXISY.AutoSize = true;
            this.AXISY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.AXISY.Location = new System.Drawing.Point(177, 167);
            this.AXISY.Name = "AXISY";
            this.AXISY.Size = new System.Drawing.Size(25, 15);
            this.AXISY.TabIndex = 28;
            this.AXISY.Text = "YY";
            // 
            // LGOBE
            // 
            this.LGOBE.AutoSize = true;
            this.LGOBE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LGOBE.Location = new System.Drawing.Point(172, 52);
            this.LGOBE.Name = "LGOBE";
            this.LGOBE.Size = new System.Drawing.Size(50, 15);
            this.LGOBE.TabIndex = 32;
            this.LGOBE.Text = "LGOBE";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(55, 52);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 13);
            this.label16.TabIndex = 31;
            this.label16.Text = "מזמין";
            // 
            // TRAY
            // 
            this.TRAY.AutoSize = true;
            this.TRAY.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TRAY.Location = new System.Drawing.Point(273, 167);
            this.TRAY.Name = "TRAY";
            this.TRAY.Size = new System.Drawing.Size(42, 15);
            this.TRAY.TabIndex = 37;
            this.TRAY.Text = "TRAY";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(55, 167);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 13);
            this.label19.TabIndex = 36;
            this.label19.Text = "מיקום:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(245, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "כמות במלאי";
            // 
            // inbox
            // 
            this.inbox.AutoSize = true;
            this.inbox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.inbox.Location = new System.Drawing.Point(351, 131);
            this.inbox.Name = "inbox";
            this.inbox.Size = new System.Drawing.Size(82, 15);
            this.inbox.TabIndex = 39;
            this.inbox.Text = "כמות במלאי";
            // 
            // TOWER
            // 
            this.TOWER.AutoSize = true;
            this.TOWER.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.TOWER.Location = new System.Drawing.Point(338, 167);
            this.TOWER.Name = "TOWER";
            this.TOWER.Size = new System.Drawing.Size(17, 15);
            this.TOWER.TabIndex = 40;
            this.TOWER.Text = "T";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(208, 169);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(11, 13);
            this.label7.TabIndex = 41;
            this.label7.Text = "-";
            // 
            // proceedOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(457, 288);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TOWER);
            this.Controls.Add(this.inbox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TRAY);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.LGOBE);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.AXISY);
            this.Controls.Add(this.AXISX);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.MENGE);
            this.Controls.Add(this.LGORT);
            this.Controls.Add(this.MAKTX);
            this.Controls.Add(this.MEINS);
            this.Controls.Add(this.MATNR);
            this.Controls.Add(this.EBELP);
            this.Controls.Add(this.EBELN);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.save);
            this.Controls.Add(this.callMigdal);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.Name = "proceedOrder";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "מסך עבודה - ניפוק";
            this.Load += new System.EventHandler(this.proceedOrder_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button callMigdal;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label EBELN;
        private System.Windows.Forms.Label EBELP;
        private System.Windows.Forms.Label MATNR;
        private System.Windows.Forms.Label MEINS;
        private System.Windows.Forms.Label MAKTX;
        private System.Windows.Forms.Label LGORT;
        private System.Windows.Forms.Label MENGE;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label AXISX;
        private System.Windows.Forms.Label AXISY;
        private System.Windows.Forms.Label LGOBE;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label TRAY;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label inbox;
        private System.Windows.Forms.Label TOWER;
        private System.Windows.Forms.Label label7;
    }
}