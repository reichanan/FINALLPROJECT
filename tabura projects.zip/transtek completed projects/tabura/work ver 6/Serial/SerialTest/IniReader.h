// IniReader.h: interface for the CIniReader class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INIREADER_H__29A1BD02_D28E_4B87_B43D_73ED9762CBAD__INCLUDED_)
#define AFX_INIREADER_H__29A1BD02_D28E_4B87_B43D_73ED9762CBAD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CIniReader
{
public:
	CIniReader(char* szFileName); 
	int ReadInteger(char* szSection, char* szKey, int iDefaultValue);
	float ReadFloat(char* szSection, char* szKey, float fltDefaultValue);
	bool ReadBoolean(char* szSection, char* szKey, bool bolDefaultValue);
	long ReadString(char* szSection, char* szKey, const char* szDefaultValue,char* o_str);

private:
	char m_szFileName[255];
};

#endif // !defined(AFX_INIREADER_H__29A1BD02_D28E_4B87_B43D_73ED9762CBAD__INCLUDED_)
