// SerialTest.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <windows.h>

#include "Serial.h"
#include "stdafx.h"
#include "IniReader.h"

using namespace std;

#define RX_BUFFSIZE 20
const short RS232_BIN_POSITION			= 0x61; //A
const short RS232_CLEAR					= 0x65; //E
const short RS232_STORE					= 0x66; //F
const short RS232_MESSSAGE				= 0x68; //H
const short RS232_ON					= 0x6B; //L
const short RS232_STOP					= 0x72; //R
const short RS232_GO					= 0x73; //S
const short RS232_SEND_STATUS			= 0x74; //T
const short RS232_GET_RS232_BUFFER      = 0x75; //U
const short RS232_INIT_PORT				= 0x7A; //Z
const short RS232_TAB				    = 0x0D; 
const short RS232_NUM0				    = 0x30;
const short RS232_NUM1				    = 0x31;
const short RS232_FEED				    = 0x04;

void buildReturnCheckMessage(char* sCommBuff)
{
	short index = 0;

	sCommBuff[index++] = RS232_SEND_STATUS; //t 
	sCommBuff[index++] = RS232_TAB; //13

	sCommBuff[index++] = RS232_NUM1;
	sCommBuff[index++] = RS232_NUM0;
	sCommBuff[index++] = RS232_NUM0;
	sCommBuff[index++] = RS232_NUM1;
	sCommBuff[index++] = RS232_NUM1;
	sCommBuff[index++] = RS232_NUM1;
	sCommBuff[index++] = RS232_NUM0;
	sCommBuff[index++] = RS232_NUM0;	
	sCommBuff[index++] = RS232_NUM1;

	sCommBuff[index++] = RS232_TAB;
	sCommBuff[index++] = RS232_FEED;
	sCommBuff[index++] = RS232_TAB;


}

void buildPositionMessage(const char* number,char* sCommBuff)
{
	short index = 0;

	sCommBuff[index++] = RS232_GET_RS232_BUFFER; //t 
	sCommBuff[index++] = RS232_TAB; //13

	sCommBuff[index++] = int(number[0] - 48)+'0';;
	sCommBuff[index++] = int(number[1] - 48)+'0';;
	sCommBuff[index++] = int(number[2] - 48)+'0';;
	sCommBuff[index++] = int(number[3] - 48)+'0';;
	sCommBuff[index++] = RS232_TAB;
	sCommBuff[index++] = RS232_FEED;
	sCommBuff[index++] = RS232_TAB;
}

int GetIntVal(string strConvert)
{ 
	int intReturn; 
	intReturn = atoi(strConvert.c_str()); 
	return(intReturn); 
}




int Write(Serial &serial, char* str)
{
	cout << "writing something to the serial port" << endl;
	serial.flush();
	int bytesWritten = serial.write(str);
	cout << bytesWritten << " bytes were written to the serial port" << endl;
	if(bytesWritten != sizeof(str) - 1)
	{
		cout << "Writing to the serial port timed out" << endl;
	}

	Sleep(100);
	return bytesWritten;
}

int Read(Serial &serial, char* buffer)
{
	//char buffer[RX_BUFFSIZE]={0};
	cout << "Reading from the serial port: ";
	int charsRead = serial.read(buffer, RX_BUFFSIZE);
	cout << buffer << endl;
	return charsRead;


}

void WriteAndRead(Serial &serial, const char* wStr,char* rStr)
{
	//cout << "writing something to the serial port" << endl;
	serial.flush();
	int bytesWritten = serial.write(wStr);
	//cout << bytesWritten << " bytes were written to the serial port" << endl;
	if(bytesWritten != sizeof(wStr) - 1)
	{
		//cout << "Writing to the serial port timed out" << endl;
	}

	Sleep(100);
	//char buffer[RX_BUFFSIZE]={0};
	//cout << "Reading from the serial port: ";
	int charsRead = serial.read(rStr, RX_BUFFSIZE);
	//cout << rStr << endl;
}

bool checkIfReady(Serial &serial)
{
	bool retVal = false;
	char buffer[RX_BUFFSIZE]={0};
	WriteAndRead(serial,"t",buffer);  //need to remove
	//buildReturnCheckMessage(buffer);

	if(strlen(buffer)==0)
		throw("ERROR: the device is not connected");

	if((buffer[0] = 't') && (buffer[1]==13) && (buffer[11]==13))
	{
		if(buffer[5] =='1')
			retVal = true;
		else
			retVal = false;
	}


	return retVal;

}


bool checkIfMachineIsWorking(Serial &serial)
{
	bool retVal = false;
	char buffer[RX_BUFFSIZE]={0};
	WriteAndRead(serial,"t",buffer);  //need to remove
	//buildReturnCheckMessage(buffer);

	if(strlen(buffer)==0)
		throw("ERROR: the device is not connected");

	if((buffer[0] = 't') && (buffer[1]==13) && (buffer[11]==13))
	{
		if(buffer[9] =='1')
			retVal = true;
		else
			retVal = false;
	}


	return retVal;

}






void checkStatus(Serial &serial)
{
	bool retVal = false;
	char buffer[RX_BUFFSIZE]={0};
	WriteAndRead(serial,"t",buffer);  //need to remove
	//buildReturnCheckMessage(buffer);

	if(strlen(buffer)==0)
		throw("ERROR: the device is not connected");

	if((buffer[0] = 't') && (buffer[1]==13) && (buffer[11]==13))
	{
		cout << endl;
		buffer[2] =='1' ? cout << "UNIT READY=1"<< endl  : cout << "UNIT READY=0"<< endl;
		buffer[3] =='1' ? cout << "UNIT LOCKED OUT=1"<< endl  : cout << "UNIT LOCKED OUT=0"<< endl;
		buffer[4] =='1' ? cout << "SAFETY STOP OCCURRED=1"<< endl  : cout << "SAFETY STOP OCCURRED=0"<< endl;
		buffer[5] =='1' ? cout << "UNIT ON=1"<< endl  : cout << "UNIT ON=0"<< endl;
		buffer[6] =='1' ? cout << "UNIT AVAILABLE=1"<< endl  : cout << "UNIT AVAILABLE=0"<< endl;
		buffer[7] =='1' ? cout << "PICK MODE ENABLED=1"<< endl  : cout << "PICK MODE ENABLED=0"<< endl;
		buffer[8] =='1' ? cout << "SET MODE ENABLED=1"<< endl  : cout << "SET MODE ENABLED=0"<< endl;
		buffer[9] =='1' ? cout << "UNIT RUNNING=1"<< endl  : cout << "UNIT RUNNING=0"<< endl;
		buffer[10] =='1' ? cout << "TASK IN PROGRESS=1"<< endl  : cout << "TASK IN PROGRESS=0"<< endl;

	}

}



int getBinPosition(Serial &serial)
{
	bool checkReady = false;
	char buffer[RX_BUFFSIZE]={0};
	string tmpStr;	

	int binPosition;
	checkReady = checkIfReady(serial);
	if(checkReady==true)
	{
		//buildPositionMessage("0041",buffer); //need to remove
		
		bool isrun = checkIfMachineIsWorking(serial);

		if(isrun)
			throw("ERROR: please wait the device is running");		
		
		WriteAndRead(serial,"u",buffer);	
		string tmpLoc = buffer;
		string str2 = tmpLoc.substr (2,4); 
		binPosition = GetIntVal(str2);
	}
	else
	{
		WriteAndRead(serial,"k",buffer);
		memset(buffer,0,sizeof(buffer));
		checkReady = checkIfReady(serial);
		if(checkReady==true)
		{
			bool isrun = checkIfMachineIsWorking(serial);

			if(isrun)
				throw("ERROR: please wait the device is running");			
			
			WriteAndRead(serial,"u",buffer);	
			string tmpLoc = buffer;
			string str2 = tmpLoc.substr (2,4); 
			binPosition = GetIntVal(str2);

		}
	}
	return binPosition;
}

bool operateDevice(Serial &serial,string Bin)
{
	bool retVal = false;
	bool checkReady = false;
	char buffer[RX_BUFFSIZE]={0};
	string tmpStr;	
	//cout << "GO:" << " Port: " << Port << "  Bin: " << Bin << endl;
	checkReady = checkIfReady(serial);
	if(checkReady==true)
	{
		bool isrun = checkIfMachineIsWorking(serial);

		if(isrun)
			throw("ERROR: please wait the device is running");
		
		tmpStr = "za" + Bin + "s";
		WriteAndRead(serial,tmpStr.c_str(),buffer);	
		retVal = true;

	}
	else
	{
		WriteAndRead(serial,"k",buffer);
		memset(buffer,0,sizeof(buffer));
		checkReady = checkIfReady(serial);
		if(checkReady==true)
		{
			bool isrun = checkIfMachineIsWorking(serial);

			if(isrun)
				throw("ERROR: please wait the device is running");			
			
			tmpStr = "za" + Bin + "s";
			WriteAndRead(serial,tmpStr.c_str(),buffer);	
			retVal = true;

		}
	}

	return retVal;

}


void getMaxBinMum(char* buffer)
{
    #define GENERAL		"General"
    #define MAXBIN	     "MAXBIN"
	CIniReader IniRead("c:\\530white.ini");
	IniRead.ReadString(GENERAL, MAXBIN ,"60", buffer);

}

void getComPortNumber(const char* sPort,char* buffer)
{
#define GENERAL		"General"
#define PORT_NAME1	"PORT1"
#define PORT_NAME2	"PORT2"
#define PORT_NAME3	"PORT3"
#define PORT_NAME4	"PORT4"
	CIniReader IniRead("c:\\530white.ini");

	int nPort = atoi(sPort);

	switch ( nPort ) 
	{
	case 1 : 
		IniRead.ReadString(GENERAL, PORT_NAME1 ,"COM1", buffer);
		break;
	case 2 : 
		IniRead.ReadString(GENERAL, PORT_NAME2 ,"COM2", buffer);
		break;
	case 3:
		IniRead.ReadString(GENERAL, PORT_NAME3 ,"COM3", buffer);
		break;
	case 4:
		IniRead.ReadString(GENERAL, PORT_NAME4 ,"COM4", buffer);
		break;
	default:
		throw("ERROR: please use Q or S or G commands with correct paramethers");
	}

}


bool checkIfBinInSameReqPos(Serial &serial,string bin)
{
	bool retVal = false;
	int binPos = getBinPosition(serial);
	int inputBin = GetIntVal(bin);
	if(binPos == inputBin)
		retVal = true;
	else
		retVal = false;

	return retVal;

}

int main(int argc, char* argv[])
{
	enum operateList 
	{
		NONE,
		GO,
		QUERY, 
		STATUS

	};

	operateList operate=NONE;
	string Port;
	string Bin;
	tstring commPortName;

	try
	{
		if(argc==2)
		{
			if(('g' == argv[1][0]) || ('G' == argv[1][0]))
			{
				operate = GO;
				
				std::string sBuffer(argv[1]);
				std::string sCarusel = sBuffer.substr (1,2);
				std::string sBin = sBuffer.substr (3,3);				
				
				Port = sCarusel;
				Bin = "0"; 
				Bin  +=sBin;
			}			
			else if(('q' == argv[1][0]) || ('Q' == argv[1][0]))
			{
				operate = QUERY;

				std::string sBuffer(argv[1]);
				std::string sCarusel = sBuffer.substr (1,2);
				Port = sCarusel;
	

			}
			else if(('s' == argv[1][0]) || ('S' == argv[1][0]))
			{
				operate = STATUS;
				std::string sBuffer(argv[1]);
				std::string sCarusel = sBuffer.substr (1,2);
				Port = sCarusel;						
				
			}
			else
				throw("ERROR: please use Q or S or G commands");

		}
		else
		{
				throw("ERROR: please use Q or S or G commands");

		}



		if(operate !=NONE)
		{
			//Port = argv[2];
			char szCom[30]={0};
			getComPortNumber(Port.c_str(),szCom);
			commPortName = szCom;
		}

		if(operate == GO)    
		{
			char szBin[10]={0};
			getMaxBinMum(szBin);
			int inputBin = GetIntVal(Bin);
			int maxBin = atoi(szBin);
			if(inputBin>maxBin)
				throw("ERROR: please check Bin number");



		}

		//cout << "Opening com port"<< endl;
		Serial serial(commPortName,9600);
		cout << "Port opened: " << commPortName << endl;

		int binPosition = 0;
		bool successOperate = false;

		switch ( operate ) 
		{

		case GO : 
			successOperate = operateDevice(serial,Bin);
			if(true == successOperate)
				cout << "GO:" << " Port: " << Port << "  Bin: " << Bin << "  successfully" << endl;
			else
				cout << "GO:" << " Port: " << Port << "  Bin: " << Bin << "  failed" << endl;
			break;
		case QUERY : 
			binPosition = getBinPosition(serial);
			cout << "QUERY:" << " Port: " << Port << "  Position: " << binPosition << endl;
			break;
		case STATUS:
			checkStatus(serial);
			//cout << "STATUS:" << " Port: " << Port << endl;
			break;

		}

	//////////////////////////////////////////////////////////////		
	}catch(const char *msg)
	{
		cout << msg << endl;
	}

	return 0;
}

