// stdafx.cpp : source file that includes just the standard includes
#include "stdafx.h"



/*		
cout << "writing something to the serial port" << endl;
serial.flush();
//char hi[] = "za0012s";
char hi[] = "a30s";
int bytesWritten = serial.write(hi);
cout << bytesWritten << " bytes were written to the serial port" << endl;
if(bytesWritten != sizeof(hi) - 1)
{
cout << "Writing to the serial port timed out" << endl;
}

char buffer[RX_BUFFSIZE]={0};

cout << "Reading from the serial port: ";
for(int i = 0; i < 10; i++)
{
int charsRead = serial.read(buffer, RX_BUFFSIZE);
cout << buffer;
Sleep(100);
}
cout << endl;
*/


		//char buffer[RX_BUFFSIZE]={0};
		//WriteAndRead(serial,"k",buffer);


		//char buffer2[RX_BUFFSIZE]={0};
		//WriteAndRead(serial,"za00132s",buffer2);		

		//char buffer1[RX_BUFFSIZE]={0};
		//WriteAndRead(serial,"u",buffer1);




	//std::string sBuffer(command);

	//std::string sCmd = sBuffer.substr (0,1);
	//std::string sCarusel = sBuffer.substr (1,2);
	//std::string sBin = sBuffer.substr (3,3);

/*

		else if(argc==4) //G 01 0001
		{
			if(('g' == argv[1][0]) || ('G' == argv[1][0]))
			{
				operate = GO;
				Bin = "0"; 
				Bin  +=argv[3];						
			}
			else
			{
				throw("ERROR: please use Q or S or G commands");
			}
		}
		else
		{
			throw("ERROR: please use Q or S or G commands with correct paramethers");
	
	}

*/
