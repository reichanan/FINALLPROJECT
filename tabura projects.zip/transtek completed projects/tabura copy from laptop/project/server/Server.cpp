//Server Socket Code

#include <iostream>
#include <process.h>
#include <windows.h>

#include "..\inc\iniReader.h"

using namespace std;

extern enum errorCode; 
extern errorCode runPort(char* argv);

short getPortMum()
{
#define SERVER		"Server"
#define PORT	     "PORT"
	char buffer[100] = {0};
	CIniReader IniRead("c:\\530white.ini");
	IniRead.ReadString(SERVER, PORT ,"8900", buffer);

	return atoi(buffer);

}


int main(int argc, char* argv[])
{
	// Initialize WinSock2.2 DLL
	// low word = major, highword = minor

	try
	{

		CRITICAL_SECTION m_cs;
		InitializeCriticalSection(&m_cs);

		short port = getPortMum();

		WSADATA wsaData = {0};
		WORD wVer = MAKEWORD(2,2);
		int nRet = WSAStartup( wVer, &wsaData );
		if( nRet == SOCKET_ERROR ) {
			// WSAGetLastError()
			cout << "Failed to init Winsock library" << endl;
			return -1;
		}
		cout << "Starting server" << endl;
		// name a socket
		WORD WSAEvent = 0;
		WORD WSAErr = 0;
		// open a socket
		//
		// for the server we do not want to specify a network address
		// we should always use INADDR_ANY to allow the protocal stack
		// to assign a local IP address
		SOCKET hSock = {0};
		hSock = socket( AF_INET, SOCK_STREAM, IPPROTO_IP );
		if( hSock == INVALID_SOCKET ) {
			cout << "Invalid socket, failed to create socket" << endl;
			return -1;
		}
		// name socket
		sockaddr_in saListen = {0};
		saListen.sin_family = PF_INET;
		saListen.sin_port = htons( port );
		saListen.sin_addr.s_addr = htonl( INADDR_ANY );
		// bind socket's name
		nRet = bind( hSock, (sockaddr*)&saListen, sizeof(sockaddr) );
		if( nRet == SOCKET_ERROR ) {
			cout << "Failed to bind socket" << endl;
			//shutdown( hSock );
			closesocket( hSock );
			return -1;
		}
		while( true )
		{
			cout << "Listening for connections" << endl;
			// listen
			nRet = listen( hSock, 5 ); // connection backlog queue set to 10
			if( nRet == SOCKET_ERROR )
			{
				int nErr = WSAGetLastError();
				if( nErr == WSAECONNREFUSED ) {
					cout << "Failed to listen, connection refused" << endl;
				}
				else {
					cout << "Call to listen failed" << endl;
				}
				closesocket( hSock );
				return -1;
			}
			// connect
			sockaddr_in saClient = {0};
			int nSALen = sizeof( sockaddr );
			SOCKET hClient = accept( hSock, (sockaddr*)&saClient, &nSALen );
			if( hClient == INVALID_SOCKET ) {
				cout << "Invalid client socket, connection failed" << endl;
				closesocket( hSock );
				return -1;
			}
			cout << "Connection estabilished" << endl;
			// process data
			char wzRec[512] = {0};
			int nLeft = 512;
			int iPos = 0;
			int nData = 0;
			do
			{
				nData = recv( hClient, &wzRec[iPos], nLeft, 0 );
				if( nData == SOCKET_ERROR ) {
					cout << "Error receiving data" << endl;
					memset( &wzRec, 0, sizeof( wzRec ) );
					break;
				}
				nLeft -= nData;
				iPos += nData;
			} while( nLeft > 0 );
			cout << "Data Recieved: " << wzRec << endl;

			//need to call here to run serial port
			EnterCriticalSection(&m_cs);
			errorCode code;
			code = runPort(wzRec);
			char* strOk = "530:OK";
			char* strBad = "530:BAD";
			if(code == 0)
			{
				strcpy(wzRec,strOk);
			}
			else
			{
				strcpy(wzRec,strBad);
			}

			LeaveCriticalSection(&m_cs);

			// echo data back to client
			iPos = 0;
			nLeft = 512;
			do
			{
				nData = send( hClient, &wzRec[iPos], nLeft, 0 );
				if( nData == SOCKET_ERROR ) {
					cout << "Error sending data" << endl;
					break;
				}
				nLeft -= nData;
				iPos += nData;
			} while( nLeft > 0 );
			// close client connection
			closesocket( hClient );
			hClient = 0;
			// perform a lowercase comparison
			if( _stricmp( wzRec, "!shutdown" ) == 0 ) {
				break;
			}
			// clear data buffer
			memset( &wzRec, 0, sizeof( wzRec ) );
		} // loop
		cout << "Shutting down the server" << endl;
		//Rajinder Yadav Copyright � 2007 www.devmentor.org
		// close server socket
		nRet = closesocket( hSock );
		hSock = 0;
		if( nRet == SOCKET_ERROR ) {
			cout << "Error failed to close socket" << endl;
		}
		// Release WinSock DLL
		nRet = WSACleanup();
		if( nRet == SOCKET_ERROR ) {
			cout << "Error cleaning up Winsock Library" << endl;
			return -1;
		}
		cout << "Server is offline" << endl;
		return 0;

		//////////////////////////////////////////////////////////////		
	}catch(const char *msg)
	{
		cout << msg << endl;
	}

}