// Test exe.cpp : Defines the entry point for the console application.
//

#include "windows.h"
#include "CaruselSerial.h"

extern errorCode runPort(char* argv);

int main(int argc, char* argv[])
{
	try
	{
		if(argc==2)
		{
			runPort(argv[1]);
		}
		else
		{
			//throw("ERROR: please use Q or S or G commands");
			throw CHECK_ARG;

		}

	}catch(const char *msg)
	{
		cout << msg << endl;
	}

	return 0;
}




