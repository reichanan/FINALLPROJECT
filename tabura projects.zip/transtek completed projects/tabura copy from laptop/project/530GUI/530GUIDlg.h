// 530GUIDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "LedButton.h"


// CMy530GUIDlg dialog
class CMy530GUIDlg : public CDialog
{
// Construction
public:
	CMy530GUIDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MY530GUI_DIALOG };
	CLedButton	m_Btn1;

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	void RUN(CString tmp);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedLeft();
	afx_msg void OnBnClickedRight();
	CEdit m_edit;
};
