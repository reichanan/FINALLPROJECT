//#pragma once
#include "..\..\inc\serial.h"


#include <iostream>
#include <strstream>
using namespace std;

class CaruselSerial :public Serial
{
public:
	CaruselSerial(const string &commPortName, const int bitRate);
	errorCode  operateDevice(string Bin);
	errorCode  getBinPosition(int& position);
	errorCode  checkStatus(string& strOutBuf);
	static void getMaxBinMum(char* buffer);
	static void getComPortNumber(const char* sPort,char* buffer);
	static int GetIntVal(const string &strConvert);
private:
	int Write(char* str);
	int Read(char* buffer);
	void WriteAndRead(const char* wStr,char* rStr);
	bool checkIfReady();
	bool checkIfMachineIsWorking();
	//bool checkIfBinInSameReqPos(string bin);

};

