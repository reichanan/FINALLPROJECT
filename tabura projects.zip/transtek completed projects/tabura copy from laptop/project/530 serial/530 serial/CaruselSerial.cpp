
#include "..\..\inc\iniReader.h"
#include "CaruselSerial.h"


#define RX_BUFFSIZE 20
/*
const short RS232_BIN_POSITION			= 0x61; //A
const short RS232_CLEAR					= 0x65; //E
const short RS232_STORE					= 0x66; //F
const short RS232_MESSSAGE				= 0x68; //H
const short RS232_ON					= 0x6B; //L
const short RS232_STOP					= 0x72; //R
const short RS232_GO					= 0x73; //S
const short RS232_SEND_STATUS			= 0x74; //T
const short RS232_GET_RS232_BUFFER      = 0x75; //U
const short RS232_INIT_PORT				= 0x7A; //Z
const short RS232_TAB				    = 0x0D; 
const short RS232_NUM0				    = 0x30;
const short RS232_NUM1				    = 0x31;
const short RS232_FEED				    = 0x04;

void buildReturnCheckMessage(char* sCommBuff)
{
	short index = 0;

	sCommBuff[index++] = RS232_SEND_STATUS; //t 
	sCommBuff[index++] = RS232_TAB; //13

	sCommBuff[index++] = RS232_NUM1;
	sCommBuff[index++] = RS232_NUM0;
	sCommBuff[index++] = RS232_NUM0;
	sCommBuff[index++] = RS232_NUM1;
	sCommBuff[index++] = RS232_NUM1;
	sCommBuff[index++] = RS232_NUM1;
	sCommBuff[index++] = RS232_NUM0;
	sCommBuff[index++] = RS232_NUM0;	
	sCommBuff[index++] = RS232_NUM1;

	sCommBuff[index++] = RS232_TAB;
	sCommBuff[index++] = RS232_FEED;
	sCommBuff[index++] = RS232_TAB;


}

void buildPositionMessage(const char* number,char* sCommBuff)
{
	short index = 0;

	sCommBuff[index++] = RS232_GET_RS232_BUFFER; //t 
	sCommBuff[index++] = RS232_TAB; //13

	sCommBuff[index++] = int(number[0] - 48)+'0';;
	sCommBuff[index++] = int(number[1] - 48)+'0';;
	sCommBuff[index++] = int(number[2] - 48)+'0';;
	sCommBuff[index++] = int(number[3] - 48)+'0';;
	sCommBuff[index++] = RS232_TAB;
	sCommBuff[index++] = RS232_FEED;
	sCommBuff[index++] = RS232_TAB;
}
*/
CaruselSerial::CaruselSerial(const string &commPortName, const int bitRate):
Serial(commPortName,bitRate)
{
}

int CaruselSerial::GetIntVal(const string &strConvert)
{ 
	int intReturn; 
	intReturn = atoi(strConvert.c_str()); 
	return(intReturn); 
}


int CaruselSerial::Write(char* str)
{
	cout << "writing something to the serial port" << endl;
	flush();
	int bytesWritten = write(str);
	cout << bytesWritten << " bytes were written to the serial port" << endl;
	if(bytesWritten != sizeof(str) - 1)
	{
		cout << "Writing to the serial port timed out" << endl;
	}

	Sleep(100);
	return bytesWritten;
}

int CaruselSerial::Read(char* buffer)
{
	//char buffer[RX_BUFFSIZE]={0};
	cout << "Reading from the serial port: ";
	int charsRead = read(buffer, RX_BUFFSIZE);
	cout << buffer << endl;
	return charsRead;


}

void CaruselSerial::WriteAndRead(const char* wStr,char* rStr)
{
	//cout << "writing something to the serial port" << endl;
	flush();
	int bytesWritten = write(wStr);
	//cout << bytesWritten << " bytes were written to the serial port" << endl;
	if(bytesWritten != sizeof(wStr) - 1)
	{
		//cout << "Writing to the serial port timed out" << endl;
	}

	Sleep(100);
	//char buffer[RX_BUFFSIZE]={0};
	//cout << "Reading from the serial port: ";
	int charsRead = read(rStr, RX_BUFFSIZE);
	//cout << rStr << endl;
}

bool CaruselSerial::checkIfReady()
{
	bool retVal = false;
	char buffer[RX_BUFFSIZE]={0};
	WriteAndRead("t",buffer);  //need to remove
	//buildReturnCheckMessage(buffer);

	if(strlen(buffer)==0)
	{
		//throw("ERROR: the device is not connected");
		throw DEVICE_NOT_CONNECTED;
	}

	if((buffer[0] = 't') && (buffer[1]==13) && (buffer[11]==13))
	{
		if(buffer[5] =='1')
			retVal = true;
		else
			retVal = false;
	}


	return retVal;

}


bool CaruselSerial::checkIfMachineIsWorking()
{
	bool retVal = false;
	char buffer[RX_BUFFSIZE]={0};
	WriteAndRead("t",buffer);  //need to remove
	//buildReturnCheckMessage(buffer);

	if(strlen(buffer)==0)
	{
		//throw("ERROR: the device is not connected");
		throw DEVICE_NOT_CONNECTED;
	}

	if((buffer[0] = 't') && (buffer[1]==13) && (buffer[11]==13))
	{
		if(buffer[9] =='1')
			retVal = true;
		else
			retVal = false;
	}


	return retVal;

}



errorCode CaruselSerial::checkStatus(string& strOutBuf)
{
	//bool retVal = false;
	errorCode retVal = BAD;

	char buffer[RX_BUFFSIZE]={0};
	WriteAndRead("t",buffer);  //need to remove
	//buildReturnCheckMessage(buffer);
	char outbuf[500]={0};

	ostrstream os(outbuf, 500, ios::app);

	if(strlen(buffer)==0)
	{
		//throw("ERROR: the device is not connected");
		throw DEVICE_NOT_CONNECTED;
	}
/*
	if((buffer[0] = 't') && (buffer[1]==13) && (buffer[11]==13))
	{
		cout << endl;
		buffer[2] =='1' ? cout << "UNIT READY=1"<< endl  : cout << "UNIT READY=0"<< endl;
		buffer[3] =='1' ? cout << "UNIT LOCKED OUT=1"<< endl  : cout << "UNIT LOCKED OUT=0"<< endl;
		buffer[4] =='1' ? cout << "SAFETY STOP OCCURRED=1"<< endl  : cout << "SAFETY STOP OCCURRED=0"<< endl;
		buffer[5] =='1' ? cout << "UNIT ON=1"<< endl  : cout << "UNIT ON=0"<< endl;
		buffer[6] =='1' ? cout << "UNIT AVAILABLE=1"<< endl  : cout << "UNIT AVAILABLE=0"<< endl;
		buffer[7] =='1' ? cout << "PICK MODE ENABLED=1"<< endl  : cout << "PICK MODE ENABLED=0"<< endl;
		buffer[8] =='1' ? cout << "SET MODE ENABLED=1"<< endl  : cout << "SET MODE ENABLED=0"<< endl;
		buffer[9] =='1' ? cout << "UNIT RUNNING=1"<< endl  : cout << "UNIT RUNNING=0"<< endl;
		buffer[10] =='1' ? cout << "TASK IN PROGRESS=1"<< endl  : cout << "TASK IN PROGRESS=0"<< endl;

	}
*/
	if((buffer[0] = 't') && (buffer[1]==13) && (buffer[11]==13))
	{
		cout << endl;
		buffer[2] =='1' ? os << "UNIT READY=1"<< endl  : os << "UNIT READY=0"<< endl;
		buffer[3] =='1' ? os << "UNIT LOCKED OUT=1"<< endl  : os << "UNIT LOCKED OUT=0"<< endl;
		buffer[4] =='1' ? os << "SAFETY STOP OCCURRED=1"<< endl  : os << "SAFETY STOP OCCURRED=0"<< endl;
		buffer[5] =='1' ? os << "UNIT ON=1"<< endl  : os << "UNIT ON=0"<< endl;
		buffer[6] =='1' ? os << "UNIT AVAILABLE=1"<< endl  : os << "UNIT AVAILABLE=0"<< endl;
		buffer[7] =='1' ? os << "PICK MODE ENABLED=1"<< endl  : os << "PICK MODE ENABLED=0"<< endl;
		buffer[8] =='1' ? os << "SET MODE ENABLED=1"<< endl  : os << "SET MODE ENABLED=0"<< endl;
		buffer[9] =='1' ? os << "UNIT RUNNING=1"<< endl  : os << "UNIT RUNNING=0"<< endl;
		buffer[10] =='1' ? os << "TASK IN PROGRESS=1"<< endl  : os << "TASK IN PROGRESS=0"<< endl;

		retVal = OK;
		strOutBuf = outbuf;

	}

	return retVal;

}

errorCode CaruselSerial::getBinPosition(int& position)
{
	bool checkReady = false;
	char buffer[RX_BUFFSIZE]={0};
	string tmpStr;
	errorCode retVal = BAD;

	//int binPosition;
	checkReady = checkIfReady();
	if(checkReady==true)
	{
		//buildPositionMessage("0041",buffer); //need to remove

		bool isrun = checkIfMachineIsWorking();

		if(isrun)
		{
			//throw("ERROR: please wait the device is running");
			throw DEVICE_IS_RUNNING;
		}
		
		WriteAndRead("u",buffer);	
		string tmpLoc = buffer;
		string str2 = tmpLoc.substr (2,4); 
		position = GetIntVal(str2);
		retVal = OK;
	}
	else
	{
		WriteAndRead("k",buffer);
		memset(buffer,0,sizeof(buffer));
		checkReady = checkIfReady();
		if(checkReady==true)
		{
			bool isrun = checkIfMachineIsWorking();

			if(isrun)
			{
				//throw("ERROR: please wait the device is running");
				throw DEVICE_IS_RUNNING;
			}

			WriteAndRead("u",buffer);	
			string tmpLoc = buffer;
			string str2 = tmpLoc.substr (2,4); 
			position = GetIntVal(str2);
			retVal = OK;

		}
	}
	return retVal;
}

errorCode CaruselSerial::operateDevice(string Bin)
{
	errorCode retVal = OK;
	bool checkReady = false;
	char buffer[RX_BUFFSIZE]={0};
	string tmpStr;	
	//cout << "GO:" << " Port: " << Port << "  Bin: " << Bin << endl;
	checkReady = checkIfReady();
	if(checkReady==true)
	{
		bool isrun = checkIfMachineIsWorking();

		if(isrun)
		{
			//throw("ERROR: please wait the device is running");
			throw DEVICE_IS_RUNNING;
		}

		tmpStr = "za" + Bin + "s";
		WriteAndRead(tmpStr.c_str(),buffer);	
		retVal = OK;

	}
	else
	{
		WriteAndRead("k",buffer);
		memset(buffer,0,sizeof(buffer));
		checkReady = checkIfReady();
		if(checkReady==true)
		{
			bool isrun = checkIfMachineIsWorking();

			if(isrun)
			{
				//throw("ERROR: please wait the device is running");
				throw DEVICE_IS_RUNNING;
			}

			tmpStr = "za" + Bin + "s";
			WriteAndRead(tmpStr.c_str(),buffer);	
			retVal = OK;

		}
	}

	return retVal;

}


void CaruselSerial::getMaxBinMum(char* buffer)
{
#define GENERAL		"General"
#define MAXBIN	     "MAXBIN"
	CIniReader IniRead("c:\\530white.ini");
	IniRead.ReadString(GENERAL, MAXBIN ,"60", buffer);

}

void CaruselSerial::getComPortNumber(const char* sPort,char* buffer)
{
#define GENERAL		"General"
#define PORT_NAME1	"PORT1"
#define PORT_NAME2	"PORT2"
#define PORT_NAME3	"PORT3"
#define PORT_NAME4	"PORT4"
	CIniReader IniRead("c:\\530white.ini");

	int nPort = atoi(sPort);

	switch ( nPort ) 
	{
	case 1 : 
		IniRead.ReadString(GENERAL, PORT_NAME1 ,"COM1", buffer);
		break;
	case 2 : 
		IniRead.ReadString(GENERAL, PORT_NAME2 ,"COM2", buffer);
		break;
	case 3:
		IniRead.ReadString(GENERAL, PORT_NAME3 ,"COM3", buffer);
		break;
	case 4:
		IniRead.ReadString(GENERAL, PORT_NAME4 ,"COM4", buffer);
		break;
	default:
		{
			//throw("ERROR: please use Q or S or G commands with correct paramethers");
			throw CHECK_ARG;
		}
	}

}

/*
bool CaruselSerial::checkIfBinInSameReqPos(string bin)
{
	bool retVal = false;
	int binPos = getBinPosition();
	int inputBin = GetIntVal(bin);
	
	
	if(binPos == inputBin)
		retVal = true;
	else
		retVal = false;

	return retVal;

}

*/