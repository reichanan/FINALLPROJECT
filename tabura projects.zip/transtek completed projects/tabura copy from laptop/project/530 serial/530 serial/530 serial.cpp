// SerialTest.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include <windows.h>

#include "Serial.h"
#include "IniReader.h"

using namespace std;

#define RX_BUFFSIZE 20

/*
int main(int argc, char* argv[])
{
	enum operateList 
	{
		NONE,
		GO,
		QUERY, 
		STATUS

	};

	operateList operate=NONE;
	string Port;
	string Bin;
	tstring commPortName;

	try
	{
		if(argc==2)
		{
			if(('g' == argv[1][0]) || ('G' == argv[1][0]))
			{
				operate = GO;
				
				std::string sBuffer(argv[1]);
				std::string sCarusel = sBuffer.substr (1,2);
				std::string sBin = sBuffer.substr (3,3);				
				
				Port = sCarusel;
				Bin = "0"; 
				Bin  +=sBin;
			}			
			else if(('q' == argv[1][0]) || ('Q' == argv[1][0]))
			{
				operate = QUERY;

				std::string sBuffer(argv[1]);
				std::string sCarusel = sBuffer.substr (1,2);
				Port = sCarusel;
	

			}
			else if(('s' == argv[1][0]) || ('S' == argv[1][0]))
			{
				operate = STATUS;
				std::string sBuffer(argv[1]);
				std::string sCarusel = sBuffer.substr (1,2);
				Port = sCarusel;						
				
			}
			else
				throw("ERROR: please use Q or S or G commands");

		}
		else
		{
				throw("ERROR: please use Q or S or G commands");

		}



		if(operate !=NONE)
		{
			//Port = argv[2];
			char szCom[30]={0};
			getComPortNumber(Port.c_str(),szCom);
			commPortName = szCom;
		}

		if(operate == GO)    
		{
			char szBin[10]={0};
			getMaxBinMum(szBin);
			int inputBin = GetIntVal(Bin);
			int maxBin = atoi(szBin);
			if(inputBin>maxBin)
				throw("ERROR: please check Bin number");



		}

		//cout << "Opening com port"<< endl;
		Serial serial(commPortName,9600);
		cout << "Port opened: " << commPortName << endl;

		int binPosition = 0;
		bool successOperate = false;

		switch ( operate ) 
		{

		case GO : 
			successOperate = operateDevice(serial,Bin);
			if(true == successOperate)
				cout << "GO:" << " Port: " << Port << "  Bin: " << Bin << "  successfully" << endl;
			else
				cout << "GO:" << " Port: " << Port << "  Bin: " << Bin << "  failed" << endl;
			break;
		case QUERY : 
			binPosition = getBinPosition(serial);
			cout << "QUERY:" << " Port: " << Port << "  Position: " << binPosition << endl;
			break;
		case STATUS:
			checkStatus(serial);
			//cout << "STATUS:" << " Port: " << Port << endl;
			break;

		}

	//////////////////////////////////////////////////////////////		
	}catch(const char *msg)
	{
		cout << msg << endl;
	}

	return 0;
}

*/