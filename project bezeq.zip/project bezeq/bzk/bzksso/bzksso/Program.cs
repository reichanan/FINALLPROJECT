﻿using System;
using System.Collections.Generic;
using System.Text;



//e.g args example "amam\\11013310", "ABC", "111.222.3.4"
//"User not authorized. Reason: User does not have permission for the specified system." GetAuthorizationBean("amam\\11013310", "ABC", "111.222.3.4");

//last edit 25.5.11 by hanan
 

namespace bzksso
{
    class Program
    {
        static void Main(string[] args)
        {

            string webService  = global::bzksso.Properties.Settings.Default.bzksso_nogaws_NogaPermissionsWS;
            string domain =      global::bzksso.Properties.Settings.Default.Domain;
            bool   debug =       global::bzksso.Properties.Settings.Default.Debug;

            if (debug)
                System.Console.WriteLine("config file: webService: {0} domain: {1} debug: {2}", webService, domain, debug);
 

            const string ErrStrRetVal = "Error";
            string retVal = "False";
            string errorDetails = "";
            System.IO.StreamWriter file = new System.IO.StreamWriter("BzqSso.txt");          
            
            try
            {
                if (args.Length != 3)
                {
                    if (debug)
                        System.Console.WriteLine("Please enter 3 arguments.");
                    file.WriteLine(ErrStrRetVal);
                    file.WriteLine("Please enter 3 arguments");
                    file.Close();
                    return;
                }

                String systemid = args[0];
				String user = args[1];				
				String ip = args[2];
		
                user = domain + user;

                if (debug)
                    System.Console.WriteLine("systemid: {0} user: {1} ip: {2}", systemid, user, ip);

                nogaws.NogaPermissionsWS ws = new nogaws.NogaPermissionsWS();
                nogaws.SSOResponseObject ssoResponseObject = ws.GetAuthorizationBean(user, systemid, ip);

                // User has permissions for the specified system.
                if (ssoResponseObject.Success == true)                   
                    retVal = "True";
                else
                {
                    // Get error details
                    if (ssoResponseObject.RCMainFrame != null)
                        errorDetails = ssoResponseObject.RCMainFrame.Description;
 
                    // Get error details
                    if (ssoResponseObject.RCWebSphere != null)
                        errorDetails = ssoResponseObject.RCWebSphere.Description;

                    // Get error details
                    if (ssoResponseObject.RCMicrosoft != null)
                        errorDetails = ssoResponseObject.RCMicrosoft.Description;

                }//end if

                file.WriteLine(retVal);

                if (errorDetails.Length!=0)
                    file.WriteLine(errorDetails);
                file.Close();

                if (debug)
                {
                    System.Console.WriteLine(retVal);
                    System.Console.WriteLine(errorDetails);
                }
          
            }//end try 
            catch (Exception e)
            {
                if (debug)
                {
                    Console.WriteLine("Exception caught. Could Not Connect To Web Service");
                    Console.WriteLine("{0} Exception caught.", e);
 
                }
                
                file.WriteLine(ErrStrRetVal);
                file.WriteLine("Exception caught, Could Not Connect To Web Service \r\n {0}.", e);
                file.Close();
            }

        }//end main
        
    }//end class 
}//end namespace
